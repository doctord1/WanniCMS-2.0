To add a view to wanniCMS 
1. Create a php file with a descriptive view name
2. use the function get_enity_information($entity_name) to get all the info you need in an array and start templating away.
Happy designing
