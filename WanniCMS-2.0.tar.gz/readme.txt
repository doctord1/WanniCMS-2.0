How to use wanniCMS

1. Download and extract WanniCMS
2. Create a new database and import the wanniCMS.sql file
3. Edit the config file in core/config.php
4. Create a file named home.view.html in views/default. This will be your initial home page
