# WanniCMS-2.0
Smaller Faster More efficient PHP backend for Serving website data or Rapidly developing new web applications
