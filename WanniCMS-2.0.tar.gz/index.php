<?php ob_start();
//~ ini_alter
//~ ('date.timezone','Africa/Lagos');
require_once('core/core.php');
render_template();
//~ render_page_bottom();
?>

