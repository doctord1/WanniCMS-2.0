<?php 
ob_start();
require_once('core/core.php');
//~ user_search();
get_json_data(URL);
  
?>
