$(document).ready(function(){
//alert('Script loaded, You may now continue');
    


  //~ $(function(){
    //~ $(".chzn-select").chosen();
  //~ });


//~ CKEDITOR.replace( '#content-area' );
});



